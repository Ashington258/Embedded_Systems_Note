# app_jpegviewer

JPG file viewer from SD card or pendrive
The source can be configured to use an sd card or flash drive.
(please copy the example pictures folder to your sd card or pendrive)
