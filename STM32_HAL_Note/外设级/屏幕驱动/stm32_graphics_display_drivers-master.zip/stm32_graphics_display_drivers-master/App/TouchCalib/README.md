# appTouchCalib

Touchscreen calibrator

How to use?
- compile
- run
- touch the 3 rectangle
- copy clipboard the printf result (i use the SWO pin for ST-LINK Serial Wire Viewer (SWV))
- paste to the appropriate location for the lcd c source
- change the LCD_ORIENTATION == ... -> ILI9325_ORIENTATION == (according to the display used)
