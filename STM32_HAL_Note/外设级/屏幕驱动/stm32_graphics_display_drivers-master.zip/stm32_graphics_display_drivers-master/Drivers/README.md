# lcd drivers

- stm32_adafruit_lcd.h / c
  LCD driver (see lcd_drv.pdf)

- stm32_adafruit_ts.h / c
  Touchscreen driver (see lcd_drv.pdf)

- lcd.h
  general LCD driver header (reverse word config enable if FSMC 8 bit + DMA enable)

- ts.h
  general touchscreen driver header

- bmp.h
  bitmap header
  (see example: App / LcdSpeedTest / beer_60x100_16.c)
